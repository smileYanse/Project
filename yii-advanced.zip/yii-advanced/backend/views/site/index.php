<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>


<!-- Start Page Header -->
<div class="page-header">
    <h1 class="title">标题</h1>
    <ol class="breadcrumb">
        <li class="active">子标题</li>
    </ol>
</div>
<!-- End Page Header -->

<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START CONTAINER -->
<div class="container-widget">

</div>
<!-- END CONTAINER -->
<!-- //////////////////////////////////////////////////////////////////////////// -->
