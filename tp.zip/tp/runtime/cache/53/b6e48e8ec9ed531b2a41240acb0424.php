<?php
//000000000060
 exit();?>
a:2:{i:0;a:5:{s:9:"role_name";s:12:"普通会员";s:7:"role_id";i:2;s:7:"node_id";i:3;s:3:"mca";s:19:"user/index/loginout";s:4:"name";s:6:"退出";}i:1;a:5:{s:9:"role_name";s:12:"普通会员";s:7:"role_id";i:2;s:7:"node_id";i:1;s:3:"mca";s:16:"user/index/index";s:4:"name";s:12:"用户中心";}}