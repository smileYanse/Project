<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:119:"C:\wampstack-5.6.19-0\apache2\htdocs\Lesson\03-oop\07-thinkphp_prj\dyy\public/../application/user\view\index\index.html";i:1508334168;s:114:"C:\wampstack-5.6.19-0\apache2\htdocs\Lesson\03-oop\07-thinkphp_prj\dyy\public/../application/user\view\layout.html";i:1508472398;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
    <meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />
    <title>Kode - Premium Bootstrap Admin Template</title>

    <!-- ========== Css Files ========== -->
    <link href="__STATIC__/css/root.css" rel="stylesheet">

</head>
<body>
<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START TOP -->
<div id="top" class="clearfix">

    <!-- Start App Logo -->
    <div class="applogo">
        <a href="index.html" class="logo">云打印用户中心</a>
    </div>
    <!-- End App Logo -->

    <!-- Start Top Right -->
    <ul class="top-right">

        <li class="dropdown link">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle hdbutton"><i class="fa fa-user color6"></i> <?php echo $userInfo['username']; ?> <span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-menu-list">
                <li role="presentation" class="dropdown-header">Profile</li>
                <li><a href="#"> 我的打印</a></li>
                <li><a href="#">Files</a></li>
                <li class="divider"></li>
                <li><a href="<?php echo url('/user/index/loginout'); ?>"> Logout</a></li>
            </ul>
        </li>

        <li class="link">
            账户余额:<?php echo !empty($userInfo['balance'])?$userInfo['balance']:'0.00'; ?>
        </li>
        <li class="link">
            <a href="#" class="notifications">充值</a>
        </li>
    </ul>
    <!-- End Top Right -->

</div>
<!-- END TOP -->
<!-- //////////////////////////////////////////////////////////////////////////// -->

<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START SIDEBAR -->
<div class="sidebar clearfix">

    <ul class="sidebar-panel nav">
        <li class="sidetitle">用户中心</li>
        <li><a href="<?php echo url('/user/index'); ?>"><span class="icon color5"><i class="fa fa-shopping-cart"></i></span>我的订单</a></li>
        <li><a href="<?php echo url('/user/creat_print'); ?>"><span class="icon color6"><i class="fa fa-print"></i></span>新建打印</a></li>
    </ul>

</div>
<!-- END SIDEBAR -->
<!-- //////////////////////////////////////////////////////////////////////////// -->

<!-- ================================================
jQuery Library
================================================ -->
<script type="text/javascript" src="__STATIC__/js/jquery.min.js"></script>



<!-- ================================================
Bootstrap Core JavaScript File
================================================ -->
<script src="__STATIC__/js/bootstrap/bootstrap.min.js"></script>

<!-- ================================================
Plugin.js - Some Specific JS codes for Plugin Settings
================================================ -->
<script type="text/javascript" src="__STATIC__/js/plugins.js"></script>

<!--弹框-->
<script type="text/javascript" src="/static/layer/layer.js"></script>
<link href="/static/resources/style.css" rel="stylesheet">

<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START CONTENT -->

<div class="content">

    <!-- Start Page Header -->
<div class="page-header">
    <h1 class="title"><?php echo $subtitle; ?></h1>
</div>
<!-- End Page Header -->

<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START CONTAINER -->
<div class="container-default">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-title">
                    文档列表
                </div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <td>订单号</td>
                            <td>下单时间</td>
                            <td>商家信息</td>
                            <td>总价</td>
                            <td>状态</td>
                            <td>操作</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo $vo['o_id']; ?></td>
                            <td><?php echo $vo['create_time']; ?></td>
                            <td><?php echo $vo['b_name']; ?></td>
                            <td><?php echo $vo['o_goods_money']; ?></td>
                            <td><?php echo \think\Config::get('order_state')[$vo['o_state']]; ?></td>
                            <td><a href="<?php echo url('/user/index/orderinfo', ['id' => $vo['o_id']]); ?>">查看订单</a></td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                    <?php echo $list->render(); ?>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- END CONTAINER -->
<!-- //////////////////////////////////////////////////////////////////////////// -->


    <!-- Start Footer -->
    <div class="row footer">
        <div class="col-md-6 text-left">
            Copyright © 2015 <a href="http://themeforest.net/user/egemem/portfolio" target="_blank">Egemem</a> All rights reserved.
        </div>
        <div class="col-md-6 text-right">
            Design and Developed by <a href="http://themeforest.net/user/egemem/portfolio" target="_blank">Egemem</a>
        </div>
    </div>
    <!-- End Footer -->


</div>
<!-- End Content -->
<!-- //////////////////////////////////////////////////////////////////////////// -->


</body>
</html>