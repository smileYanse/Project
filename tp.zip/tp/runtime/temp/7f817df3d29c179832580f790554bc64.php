<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:120:"C:\wampstack-5.6.19-0\apache2\htdocs\Lesson\03-oop\07-thinkphp_prj\dyy\public/../application/index\view\index\index.html";i:1507878050;s:115:"C:\wampstack-5.6.19-0\apache2\htdocs\Lesson\03-oop\07-thinkphp_prj\dyy\public/../application/index\view\layout.html";i:1508164855;}*/ ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>打印云-校园云打印|校园自助打印|在线打印|云打印|校园网络打印|网络打印|寝室打印|大学校园打印|中国在线打印第一品牌</title>
    <meta name="keywords" content="云打印,打印云,校园云打印,在线打印,校园打印,校园自助打印,校园网络打印,网络打印,寝室打印,大学校园打印"/>
    <meta name="description" content="打印云是恒泰科技云旗下系列产品之一,帮助用户实现网络资料打印,文件存储,文件共享,无需U盘,无需零钱,无需排队,自助提取,方便快捷."/>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
    <meta content="webkit" name="renderer"/>
    <link href="__STATIC__/Css/common_all.css"  rel="stylesheet" />
    <link href="__STATIC__/Css/base.css"  rel="stylesheet" type="text/css" />
    <link href="__STATIC__/Css/mian.css"  rel="stylesheet" type="text/css" />
    <link rel="shortcut icon" type="image/x-icon" href="http://oss.dayinyun.cn/Public/Home/favicon.ico" />
</head>
<body class="g-doc">
<div class="g-hd m-hd m-hd-1">
    <div class="w960 f-pr">
        <a href=""  class="logo"></a>
        <a href="http://wpa.qq.com/msgrd?v=3&uin=3184714902&site=qq&menu=yes"  target="_blank" class="qq"></a>
        <dl class="u-nav f-ib">
            <dd><a href="<?php echo url('/user/signin'); ?>">登录</a></dd>
            <dt></dt>
            <dd><a href="<?php echo url('/user/signup'); ?>" >快速注册</a></dd>

            <dt style="padding-right: 5px;"></dt>
            <dd class="u-menu">
                <a target="_blank" class="f-ib toggle" href="http://www.hilltek.net/" >更多
                    <span class="triangle_down"></span>
                </a>
                <ul>
                    <li><a target="_blank" href="http://www.bzznjj.com/" >智慧·云家居</a></li>
                    <li><a target="_blank" href="http://www.dayinyun.cn/" >智慧·云打印</a></li>
                    <li><a target="_blank" href="http://www.hilltek.net/" >智慧·云洗衣</a></li>
                </ul>
            </dd>
        </dl>
    </div>
</div>
<div class="g-bd">
    <div class="m-main">
        <div class="m-ct-1">
            <div class="w960 f-pr">
                <div class="u-msg">
                    <h1 class="title">在线打印</h1>

                    <p class="f-wwb">不出门就能打印，网上支付，无需U盘，还不用排队哟！</p>
                    <a class="btn" href="<?php echo url('/user/index'); ?>" title="云打印立刻打印">立刻打印</a>
                    <div class="msg"></div>
                </div>
            </div>
        </div>
        <div class="m-ct-2">
            <dl class="u-lst w960 f-cb">
                <dd>
                    <h2 class="title">上传附件</h2>

                    <p class="f-wwb">当前仅支持doc、docx或pdf格式文件</p>
                </dd>
                <dt></dt>
                <dd>
                    <h2 class="title">页面设置</h2>

                    <p class="f-wwb">设置打印份数，布局、装订方式</p>
                </dd>
                <dt></dt>
                <dd>
                    <h2 class="title">支付打印</h2>

                    <p class="f-wwb">通过支付宝简单充值，首充10元送1元哦</p>
                </dd>
                <dt></dt>
                <dd>
                    <h2 class="title">线下取单</h2>

                    <p class="f-wwb">打印完成后，去店铺免排队优先领取</p>
                </dd>
            </dl>
        </div>
    </div>
</div>
<div class="tk">
    <div class="ewm"><img src="http://oss.dayinyun.cn/Public/Home/Images/ewm.png" id="ewmsrc" alt="在线打印登陆二维码"><span id="ewmnotice">请用微信扫码二维码</span></div>
</div>
<div class="m-foot">
    <div class="w960">
        <div class="cprt">
            <div class="link">
                <a href="/Index/help"  target="_blank">新手指南</a><span>|</span>
                <a href="/Index/help#p_guide_shop"  target="_blank">打印店指南</a><span>|</span>
                <a href="/Index/help#p_proto_file"  target="_blank">文档分享协议</a><span>|</span>
                <a href="/Index/help#p_proto_user"  target="_blank">用户注册协议</a><span>|</span>
                <a href="/Index/help#p_proto_shop"  target="_blank">打印店加盟协议</a><span>|</span>
                <a href="/zaixiandayindian"  target="_blank" title="在线打印店商家列表">在线打印商家列表</a><span>|</span>
                <a href="/Shop/Index/index" style="color:red;" target="_blank">商家入驻</a><span>|</span>
                <a href="/FilesCenter" style="color:red;" target="_blank">校园文库</a>
            </div>
            <div class="msg">
                打印云&copy;2017&nbsp;&nbsp;&nbsp;&nbsp; 西安恒泰网络科技有限公司&nbsp;&nbsp; 陕ICP备11001048号-1&nbsp;&nbsp;
            </div>
        </div>
    </div>
</div>
</body>
<script type="text/javascript" src="http://oss.dayinyun.cn/Public/Home/Js/jquery-1.8.2.min.js" ></script>
<script type="text/javascript" src="http://oss.dayinyun.cn/Public/Home/Js/layer/layer.min.js" id = "layer"></script>
<script type="text/javascript">
    var PUBLIC= "http://oss.dayinyun.cn/Public";
    var APP = "";
    var ROOT = "";
    var URL = "/Index";
</script>
<script type="text/javascript" src="http://oss.dayinyun.cn/Public/Home/Js/dy.index.js" ></script>
</html>