<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:120:"C:\wampstack-5.6.19-0\apache2\htdocs\Lesson\03-oop\07-thinkphp_prj\dyy\public/../application/user\view\signin\index.html";i:1508467201;}*/ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
    <meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />
    <title>Kode - Premium Bootstrap Admin Template</title>

    <!-- ========== Css Files ========== -->
    <link href="__STATIC__/css/root.css" rel="stylesheet">
    <style type="text/css">
        body{background: #F5F5F5;}
    </style>
</head>
<body>

<div class="login-form">
    <form action="" method="post">
        <div class="top">
            <!--<img src="img/kode-icon.png" alt="icon" class="icon">-->
            <h1><?php echo $subTitle; ?></h1>
            <!--<h4>Login in YDD</h4>-->
        </div>
        <div class="form-area">
            <div class="group <?php echo !empty($errors['username'])?'has-error':''; ?>">
                <input name="username" type="text" class="form-control" placeholder="Username" value="<?php echo \think\Request::instance()->post('username')?:'super'; ?>">
                <i class="fa fa-user"></i>
                <span class="help-block"><?php echo !empty($errors['username'])?$errors['username']:''; ?></span>
            </div>
            <div class="group <?php echo !empty($errors['passwd'])?'has-error':''; ?>">
                <input name="passwd" type="password" class="form-control" placeholder="Password" value="<?php echo \think\Request::instance()->post('passwd')?:'123456'; ?>">
                <i class="fa fa-key"></i>
                <span class="help-block"><?php echo !empty($errors['passwd'])?$errors['passwd']:''; ?></span>
            </div>
            <div class="group <?php echo !empty($errors['captcha'])?'has-error':''; ?>">
                <input name="captcha" type="text" class="form-control" placeholder="captcha" value="<?php echo \think\Request::instance()->post('captcha'); ?>">
                <i class="fa fa-pencil-square-o"></i>
                <span class="help-block"><?php echo !empty($errors['captcha'])?$errors['captcha']:''; ?></span>
            </div>
            <img src="<?php echo captcha_src(); ?>" onclick="this.src = this.src + '?' + Math.random()" alt="captcha" />

            <button type="submit" class="btn btn-default btn-block">LOGIN</button>
        </div>
    </form>
    <div class="footer-links row">
        <div class="col-xs-6"><a href="/user/signup"><i class="fa fa-external-link"></i> Register Now</a></div>
        <div class="col-xs-6 text-right"><a href="#"><i class="fa fa-lock"></i> Forgot password</a></div>
    </div>
</div>

</body>
</html>